const express = require("express"),
	  app = express(),
	  mongoose = require("mongoose"),
	  bodyParser =require ("body-parser"),
	  methodOverride = require("method-override");

//APP CONFIG
mongoose.connect("mongodb://localhost/restfulblogapp",{useNewUrlParser: true, useUnifiedTopology: true});
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));
app.use(methodOverride("_method"));
//MONGOOSE MODEL CONFIG
const blogSchema = mongoose.Schema({
	title: String,
	image: String,
	body: String,
	created: {type: Date, default: Date.now}
});

const Blog = mongoose.model("Blog", blogSchema);


// RESTFUL ROUTES
app.get("/", (req, res)=>{
	res.redirect("/blogs");
});

//INDEX - Showing all blogs
app.get("/blogs", (req, res)=> {
	Blog.find({}, (err, blogs)=>{
		if(err)
			console.log("ERROR OCURRED");
		else 
			res.render("index", {blogs: blogs});	
	})
});

//NEW
app.get("/blogs/new", (req, res)=>{
	res.render("new");
});

//CREATE
app.post("/blogs", (req, res)=> {
	Blog.create(req.body.blog, (err, newBlog)=>{
		if(err)
			res.redirect("new");
	else
		res.redirect("/blogs");
	});
});

//SHOW
app.get("/blogs/:id", (req, res)=>{
	Blog.findById(req.params.id, (err, blog)=>{
		if(err)
			{
				console.log("ERROR OCCURRED!!!!");
				console.log(err);
			}
			
		else res.render("show", {blog: blog});
	});
});

// EDIT ROUTE
app.get("/blogs/:id/edit",(req, res)=>{
	Blog.findById(req.params.id, (err, foundBlog)=>{
		if(err)
			res.redirect("/blogs");
		else
			res.render("edit", {blog: foundBlog});
	});
});

// UPDATE ROUTE
app.put("/blogs/:id", (req, res)=>{
	Blog.findByIdAndUpdate(req.params.id, req.body.blog, (err, updatedBlog)=>{
		if(err)
			{res.redirect("/blogs");
			console.log(err);}
		else res.redirect("/blogs/" + req.params.id);
	});
});

// DELETE Route
app.delete("/blogs/:id", (req, res)=>{
	Blog.findByIdAndRemove(req.params.id, (err)=>{
		if(err)
			res.redirect("/blogs");
		else res.redirect("/blogs");
	});
});

app.listen("3000", ()=>{
	console.log("server connected for RESTful blog")
})
