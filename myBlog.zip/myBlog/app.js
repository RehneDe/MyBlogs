const express = require("express"),
      app = express(),
      bodyParser = require("body-parser"),
	  expressSanitizer = require("express-sanitizer"),
      methodOverride = require("method-override"),
      mongoose= require("mongoose");

//APP CONFIG      
mongoose.connect("mongodb://localhost/myblog", {useNewUrlParser: true, useUnifiedTopology: true});
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({extended: true}));
app.use(expressSanitizer());	
app.use(methodOverride("_method"));
app.use(express.static("public"));

// MONGOOSE MODEL CONFIG
const blogSchema = mongoose.Schema({
    name: String,
	image: String,
    body: String,
    created: {type: Date, default: Date.now}
});

const Blog = mongoose.model("Blog", blogSchema);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Blog.create({
//     name: "Hacker",
//     image: "https://c4.wallpaperflare.com/wallpaper/47/95/705/anonymus-hacker-computer-mask-wallpaper-preview.jpg",
//     body: "Hacker can hack your comapany, so be aware and keep an Ethical Hacker in your Team"
// }, (err, blog)=>{
//     if(err)
//     {
//         alert("ERROR OCCURRED! REFRESHING THE PAGE");
//         res.redirect("/blogs");
//     }
//     else
//         console.log(blog);
// });
///////////////////////////////////////////////////////////||||||||||||||||||||||||||||||||ROUTES||||||||||||||||||||||||||||||||||///////////////////////////////////////////////////////////////

app.get("/",(req, res)=>{
    res.redirect("/blogs")
});
// INDEX ROUTE
app.get("/blogs", (req, res)=>{
    Blog.find({}, (err, blogs)=>{
        if(err)
        {
            alert("ERROR OCCURRED! REFRESHING THE PAGE");
            res.redirect("/blogs");
        }
        else
            res.render("index", {blogs: blogs});
    });
});

// NEW ROUTE
app.get("/blogs/new", (req, res)=>{
    res.render("new");
});

// CREATE ROUTE
app.post("/blogs",(req, res)=>{
	req.body.blog.body = req.sanitize(req.body.blog.body);
    Blog.create(req.body.blog, (err, blog)=>{
        if(err)
        {
            alert("ERROR OCCURRED! REFRESHING THE PAGE");
            res.redirect("new");
        }
        else
            res.redirect("/blogs");
    });
});

// SHOW ROUTE
app.get("/blogs/:id", (req, res)=>{
    Blog.findById(req.params.id, (err, blog)=>{
        if(err)
        {
            alert("ERROR OCCURRED! REFRESHING THE PAGE");
            res.redirect("/blogs");
        }
        else
            res.render("show", {blog: blog});  
    });
});

// EDIT
app.get("/blogs/:id/edit", (req, res)=>{
    Blog.findById(req.params.id, (err, foundBlog)=>{
        if(err)
        {
            alert("ERROR OCCURRED! REFRESHING THE PAGE");
            res.redirect("/blogs");
        }
        else
            res.render("edit", {blog: foundBlog});  
    });
});


// UPDATE
app.put("/blogs/:id", (req, res)=>{
	req.body.blog.body = req.sanitize(req.body.blog.body);
    Blog.findByIdAndUpdate(req.params.id, req.body.blog, (err, foundBlog)=>{
        if(err)
        {
            alert("ERROR OCCURRED! REFRESHING THE PAGE");
            res.redirect("/blogs");
        }
        else
            res.redirect("/blogs/" + req.params.id);  
    });
});

// DESTROY
app.delete("/blogs/:id", (req, res)=>{
    Blog.findByIdAndRemove(req.params.id, (err)=>{
        if(err)
        {
            alert("ERROR OCCURRED! REFRESHING THE PAGE");
            res.redirect("/blogs");
        }
        else
            res.redirect("/blogs");  
    });
});


app.listen(3000, ()=>{
    console.log("U R READY TO ROCK!!!");
});